// An Anthology of Interest: Applied Cryogenics
// Written by Simon Lundmark

#include <stdio.h>
#include <string.h>

char* unused_shell = "/bin/sh";

void check_date() {
	printf("Todays date? Sure, here it is:\n");
	system("/bin/date");
}

void apply_career_chip(char* string) {
	char career_chip[100];
	strcpy(career_chip, string);
	printf("Contratulations, you are now a delivery boy!\n");
}

int main(int argc, char** argv) {
	printf("+--------------------+\n");
	printf("| Applied Cryogenics |\n");
	printf("+--------------------+\n");
	printf("Enter any string to select career-chip for delivery boy\n");
	apply_career_chip(argv[1]);
	return 0;
}