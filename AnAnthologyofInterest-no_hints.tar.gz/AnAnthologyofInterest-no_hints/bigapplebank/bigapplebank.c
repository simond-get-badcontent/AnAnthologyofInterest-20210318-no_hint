// An Anthology of Interest: Big Apple Bank
// Written by Simon Lundmark

#include <stdio.h>
#include <string.h>

int main(void)
{
	char pin_number[15];
	int correct = 0;

	printf("+---------------------------+ \n");
	printf("| Welcome to Big Apple Bank | \n");
	printf("+---------------------------+ \n");
	printf("\nWhat's your secret PIN number? \n");
	gets(pin_number);

	if(strcmp(pin_number, "1077"))
	{
		printf ("\nWrong secret PIN number \n");
	}
	else
	{
		printf ("\nCorrect PIN number. \n");
		correct = 1;
	}

	if(correct)
	{
        	printf ("\nWelcome Fry, your balance is: \n");
		printf ("$4.3 billion \n");
   	}

	return 0;
}