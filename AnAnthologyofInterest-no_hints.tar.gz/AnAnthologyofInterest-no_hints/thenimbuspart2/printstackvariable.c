// An Anthology of Interest: The ASLR project
// Written by Simon Lundmark

#include <stdio.h>

int main()
{
    	int a;
    	printf("Variable location: %p\n", &a);
    	return 0;
}