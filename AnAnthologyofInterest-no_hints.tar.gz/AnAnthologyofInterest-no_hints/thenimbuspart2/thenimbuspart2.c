// An Anthology of Interest: The Nimbus
// Written by Simon Lundmark

#include <stdio.h>
#include <string.h>

void check_name(char *answer)
{
	char name[100];
	strcpy(name, answer);
	printf("You: %s\n", name);
	printf("Zapp Brannigan: %s, now that's a name I can trust!\n", name);
}

int main(int argc, char *argv[])
{
	printf("+--------------------+\n");
	printf("| Onboard the Nimbus |\n");
	printf("+--------------------+\n");
	printf("Zapp Brannigan: You, Ensign, what's your name?\n");
	check_name(argv[1]);
	return 0;
}