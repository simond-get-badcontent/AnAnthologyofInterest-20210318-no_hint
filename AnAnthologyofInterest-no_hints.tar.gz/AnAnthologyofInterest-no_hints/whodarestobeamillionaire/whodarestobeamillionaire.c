// An Anthology of Interest: Who Dares to be a Millionare?
// Written by Simon Lundmark

#include <stdio.h>
#include <string.h>

void secret_function() {
	printf("Whoha! You found the secret function!\n");
}

void check_answer(char* string) {
	char answer[100];
	strcpy(answer, string);
	if(strcmp(answer, "A hammer"))
	{
		printf("Wrong answer!\n");
	}
	else
	{
		printf ("Correct answer!\n");
	}
}

int main(int argc, char** argv) {
	printf("+--------------------------------+\n");
	printf("| Who Dares To Be A Millionaire? |\n");
	printf("+--------------------------------+\n");
	printf("Morbo the Annihilator: What tool is used to hammer a nail?\n");
	printf("A. A hammer | B. A nail\n");
	check_answer(argv[1]);
	return 0;
}